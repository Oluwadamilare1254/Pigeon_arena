import React, { useState, useEffect } from 'react';
import { Home, TrendingUp, MessageSquare, Search, ChevronLeft, ChevronRight, Eye, EyeOff, Sun, Moon, Menu, Bell, Wallet, X, MoreVertical, Share2, Bookmark, VolumeX, Flag, Ban, BarChart3, ArrowUpRight, ArrowDownRight, Users } from 'lucide-react';

const PigeonApp = () => {
  const [currentScreen, setCurrentScreen] = useState('welcome');
  const [darkMode, setDarkMode] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [showMenu, setShowMenu] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [selectedMarket, setSelectedMarket] = useState(null);
  
  // Auth states
  const [authStep, setAuthStep] = useState('welcome');
  const [phoneOrEmail, setPhoneOrEmail] = useState('email');
  const [verificationCode, setVerificationCode] = useState(['', '', '', '']);
  const [username, setUsername] = useState('');
  const [dob, setDob] = useState('');

  // Mock data
  const mockUser = {
    name: 'Dotadams',
    avatar: '👤',
    walletBalance: 3000000.9,
    walletAddress: '0xt790...e4cb',
    rank: '3A 99 C9 PI',
    date: '7 / 25'
  };

  const mockPosts = [
    {
      id: 1,
      author: 'Pigeon',
      handle: '@PigeonUniverse',
      verified: true,
      time: '8:59AM • 19/10/25',
      content: 'Excited to announce the launch of Pigeon Nest. A personal tool for users to engage more with each other, bond over shared interests, etc. More to come.',
      comments: 1200,
      shares: 711,
      reactions: { fire: 3300, heart: 2700, edit: 9, thumbs: 1600, rocket: 1300 },
      type: 'announcement'
    },
    {
      id: 2,
      author: 'Culture',
      handle: '@Culture',
      verified: true,
      time: '11/6/25',
      content: 'The Future is shared',
      market: {
        question: 'Will Davido drop an Album in 2026?',
        category: 'Culture - Afro beats',
        endDate: '31/12/26',
        options: [
          { label: 'Yes', price: '₦5000', percentage: 59, trend: 'up' },
          { label: 'No', price: '₦4000', percentage: 41, trend: 'down' }
        ],
        totalVolume: '₦46,357,211'
      },
      comments: 3300,
      shares: 102000,
      reactions: { laugh: 11100, fire: 9300 }
    },
    {
      id: 3,
      author: 'Politics',
      handle: '@Politics',
      verified: true,
      time: '9:21AM • 23/4/25',
      content: 'Who you got? 👀',
      market: {
        question: 'Who will be the next Nigerian President?',
        category: 'Politics',
        endDate: '2027',
        options: [
          { label: 'Bola Ahmed Tinubu', price: '₦59', percentage: 40 },
          { label: 'Peter Obi', price: '₦41', percentage: 30 },
          { label: 'Atiku Abubakar', price: '₦26', percentage: 20 },
          { label: 'El Rufai', price: '₦11', percentage: 10 }
        ],
        totalVolume: '₦704,651,902'
      },
      comments: 1200,
      shares: 711,
      reactions: { fire: 3300, heart: 2700, thumbs: 1600, rocket: 1300 }
    }
  ];

  const mockLeaderboard = [
    { rank: 1, name: 'Mike', handle: '@MPremium', wins: 30, avatar: '🎯' },
    { rank: 2, name: 'Florence', handle: '@FLC', wins: 27, avatar: '🎨' },
    { rank: 3, name: 'FORTUNE', handle: '@fortune', wins: 21, avatar: '🎲' },
    { rank: 4, name: 'Sarah.com', handle: '@ssssarah', wins: 19, avatar: '🎪' },
    { rank: 5, name: 'gp', handle: '@gp', wins: 13, avatar: '🎭' }
  ];

  const WelcomeScreen = () => (
    <div className={`min-h-screen flex flex-col items-center justify-center p-6 ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
      <button onClick={() => setCurrentScreen('home')} className="absolute top-6 left-6">
        <X size={24} />
      </button>
      
      <div className="text-center mb-12">
        <div className="text-6xl mb-6">👀</div>
        <h1 className="text-4xl font-bold mb-2">Welcome to Pigeon</h1>
        <p className={`text-lg ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Move With The Flock</p>
      </div>

      <div className="w-full max-w-md space-y-4">
        <button onClick={() => setAuthStep('signup')} className="w-full bg-white text-black py-4 rounded-full font-semibold flex items-center justify-center space-x-2">
          <span>🍎</span>
          <span>Continue with Apple</span>
        </button>
        
        <button onClick={() => setAuthStep('signup')} className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} py-4 rounded-full font-semibold flex items-center justify-center space-x-2`}>
          <span>🔵</span>
          <span>Continue with Google</span>
        </button>
        
        <button onClick={() => setAuthStep('SignUpFlow')} className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} py-4 rounded-full font-semibold`}>
          Get Started
        </button>
        
        <button onClick={() => setAuthStep('login')} className={`w-full ${darkMode ? 'bg-transparent border border-gray-700' : 'bg-transparent border border-gray-300'} py-4 rounded-full font-semibold`}>
          Log in
        </button>
      </div>
    </div>
  );

  const SignupFlow = () => {
    if (authStep === 'phone') {
      return (
        <div className={`min-h-screen p-6 ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
          <button onClick={() => setAuthStep('signup')} className="mb-12">
            <ChevronLeft size={24} />
          </button>
          
          <h1 className="text-3xl font-bold mb-2">What's your number?</h1>
          
          <div className="flex space-x-3 mt-8">
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-gray-200'} px-4 py-3 rounded-lg flex items-center space-x-2`}>
              <span>🇳🇬</span>
            </div>
            <input 
              type="tel" 
              placeholder="+ 234"
              className={`flex-1 ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} px-4 py-3 rounded-lg outline-none`}
            />
          </div>

          <button onClick={() => setAuthStep('email')} className="mt-6 text-blue-500">
            Use email instead
          </button>

          <button 
            onClick={() => setAuthStep('verification')}
            className="w-full bg-white text-black py-4 rounded-full font-semibold mt-auto absolute bottom-6 left-6 right-6"
          >
            Continue
          </button>
        </div>
      );
    }

    if (authStep === 'email') {
      return (
        <div className={`min-h-screen p-6 ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
          <button onClick={() => setAuthStep('phone')} className="mb-12">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-3xl font-bold mb-2">What's your email?</h1>
          <input 
            type="email" 
            placeholder=""
            className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} px-4 py-3 rounded-lg outline-none mt-8 border-l-4 border-red-500`}
          />

          <button onClick={() => setAuthStep('phone')} className="mt-6 text-blue-500">
            Use number instead
          </button>

          <div className="absolute bottom-6 left-6 right-6">
            <button 
              onClick={() => setAuthStep('verification')}
              className="w-full bg-white text-black py-4 rounded-full font-semibold"
            >
              Continue
            </button>
            <button className="w-full mt-4 text-blue-500">
              I already have an account
            </button>
          </div>
        </div>
      );
    }

    if (authStep === 'verification') {
      return (
        <div className={`min-h-screen p-6 ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
          <button onClick={() => setAuthStep('email')} className="mb-12">
            <ChevronLeft size={24} />
          </button>
          
          <h1 className="text-3xl font-bold mb-2">Enter code</h1>
          <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-8`}>
            We sent a verification code to your phone number,<br/>+234-9165702885
          </p>
          
          <div className="flex space-x-4 justify-center mb-6">
            {verificationCode.map((digit, i) => (
              <input
                key={i}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => {
                  const newCode = [...verificationCode];
                  newCode[i] = e.target.value;
                  setVerificationCode(newCode);
                }}
                className={`w-16 h-16 text-center text-2xl ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-lg outline-none`}
              />
            ))}
          </div>

          <div className="text-right text-sm mb-8">00:41</div>

          <button className="text-blue-500 mb-12">
            Didn't receive any code? <span className="underline">Resend Code</span>
          </button>

          <button 
            onClick={() => setAuthStep('username')}
            className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-300'} text-gray-500 py-4 rounded-full font-semibold`}
          >
            Continue
          </button>
        </div>
      );
    }

    if (authStep === 'username') {
      return (
        <div className={`min-h-screen p-6 ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
          <button onClick={() => setAuthStep('verification')} className="mb-12">
            <ChevronLeft size={24} />
          </button>
          
          <h1 className="text-3xl font-bold mb-8">Create an account</h1>
          
          <input 
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="dotadams"
            className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} px-4 py-3 rounded-lg outline-none mb-6`}
          />

          <input 
            type="password"
            placeholder="Hjbbgd92gdbndiklo"
            className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} px-4 py-3 rounded-lg outline-none relative`}
          />
          <p className="text-green-500 text-sm mt-2">Strong!</p>

          <button 
            onClick={() => setAuthStep('age')}
            className="w-full bg-white text-black py-4 rounded-full font-semibold mt-auto absolute bottom-6 left-6 right-6"
          >
            Next
          </button>
        </div>
      );
    }

    if (authStep === 'age') {
      return (
        <div className={`min-h-screen p-6 ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
          <button onClick={() => setAuthStep('username')} className="mb-12">
            <ChevronLeft size={24} />
          </button>
          
          <h1 className="text-3xl font-bold mb-2">How old are you?</h1>
          
          <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-6`}>Date of Birth</p>
          
          <input 
            type="text"
            value="12/11/2005"
            className={`w-full ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} px-4 py-3 rounded-lg outline-none`}
          />

          <p className={`${darkMode ? 'text-gray-500' : 'text-gray-600'} text-sm mt-4`}>
            You must be 18 and above to join Pigeon.
          </p>

          <div className="absolute bottom-6 left-6 right-6">
            <p className={`text-xs ${darkMode ? 'text-gray-500' : 'text-gray-600'} mb-4`}>
              By clicking "Enter Pigeon," you agree to Pigeon's{' '}
              <span className="text-blue-500">Terms of Service</span> and have read the{' '}
              <span className="text-blue-500">Privacy Policy</span>
            </p>
            <button 
              onClick={() => {
                setIsAuthenticated(true);
                setCurrentScreen('home');
              }}
              className="w-full bg-white text-black py-4 rounded-full font-semibold"
            >
              Enter Pigeon
            </button>
          </div>
        </div>
      );
    }

    return <WelcomeScreen />;
  };

  const HomeScreen = () => (
    <div className={`min-h-screen ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Header */}
      <div className={`sticky top-0 ${darkMode ? 'bg-black' : 'bg-white'} border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'} p-4 flex items-center justify-between z-10`}>
        <button onClick={() => setShowMenu(true)}>
          <Menu size={24} />
        </button>
        
        <div className="flex items-center space-x-4">
          <Wallet size={24} onClick={() => setCurrentScreen('wallet')} className="cursor-pointer" />
          <Bell size={24} />
          <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
            {mockUser.avatar}
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex space-x-2 p-4 overflow-x-auto">
        <button className="px-4 py-2 bg-blue-500 text-white rounded-full flex items-center space-x-2 whitespace-nowrap">
          <Home size={16} />
          <span>Home</span>
        </button>
        <button className={`px-4 py-2 ${darkMode ? 'bg-green-900' : 'bg-green-200'} ${darkMode ? 'text-green-400' : 'text-green-800'} rounded-full flex items-center space-x-2 whitespace-nowrap`}>
          <span>⚽</span>
          <span>Sports</span>
        </button>
        <button className={`px-4 py-2 ${darkMode ? 'bg-yellow-900' : 'bg-yellow-200'} ${darkMode ? 'text-yellow-400' : 'text-yellow-800'} rounded-full flex items-center space-x-2 whitespace-nowrap`}>
          <span>🏛️</span>
          <span>Politics</span>
        </button>
        <button className={`px-4 py-2 ${darkMode ? 'bg-pink-900' : 'bg-pink-200'} ${darkMode ? 'text-pink-400' : 'text-pink-800'} rounded-full flex items-center space-x-2 whitespace-nowrap`}>
          <span>🎭</span>
          <span>Culture</span>
        </button>
      </div>

      {/* Featured Market */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Today's Biggest Market</h2>
          <ChevronRight size={20} />
        </div>
        <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-4`}>Move with the Flock!</p>
        <div className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-2xl h-64 mb-4`}></div>
      </div>

      {/* Posts Feed */}
      <div className="space-y-4">
        {mockPosts.map(post => (
          <div key={post.id} className={`border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'} p-4`}>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 ${post.author === 'Pigeon' ? 'bg-red-500' : post.author === 'Culture' ? 'bg-pink-500' : 'bg-yellow-500'} rounded-lg flex items-center justify-center`}>
                  {post.author === 'Pigeon' ? '🐦' : post.author === 'Culture' ? '🎭' : '🏛️'}
                </div>
                <div>
                  <div className="flex items-center space-x-1">
                    <span className="font-bold">{post.author}</span>
                    {post.verified && <span className="text-yellow-500">✓</span>}
                  </div>
                  <span className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>{post.handle}</span>
                </div>
              </div>
              <button onClick={() => setSelectedPost(post)}>
                <MoreVertical size={20} />
              </button>
            </div>

            <p className="mb-3">{post.content}</p>
            <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'} mb-3`}>{post.time}</p>

            {post.market && (
              <div 
                onClick={() => setSelectedMarket(post.market)}
                className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-xl p-4 mb-3 cursor-pointer`}
              >
                <div className="flex items-center space-x-2 mb-3">
                  <div className={`w-8 h-8 ${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-full`}></div>
                  <div>
                    <p className="font-semibold">{post.market.question}</p>
                    <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                      {post.market.category} • {post.market.endDate}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  {post.market.options.map((option, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span>{option.label}</span>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold">{option.price}</span>
                        <span className={option.trend === 'up' ? 'text-green-500' : 'text-red-500'}>
                          {option.percentage}%
                        </span>
                        {option.trend === 'up' ? <ArrowUpRight size={16} className="text-green-500" /> : <ArrowDownRight size={16} className="text-red-500" />}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-700">
                  <div className="flex items-center space-x-1 text-sm">
                    <BarChart3 size={16} />
                    <span>{post.market.totalVolume}</span>
                  </div>
                  <button className="text-blue-500 text-sm">Full details</button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1">
                  <MessageSquare size={18} />
                  <span>{post.comments.toLocaleString()}</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Share2 size={18} />
                  <span>{post.shares.toLocaleString()}</span>
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-4 mt-3">
              {Object.entries(post.reactions).map(([emoji, count]) => (
                <span key={emoji} className="flex items-center space-x-1">
                  <span>{emoji === 'fire' ? '🔥' : emoji === 'heart' ? '❤️' : emoji === 'edit' ? '✏️' : emoji === 'thumbs' ? '👍' : emoji === 'rocket' ? '🚀' : '😂'}</span>
                  <span className="text-sm">{(count / 1000).toFixed(1)}K</span>
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 ${darkMode ? 'bg-black border-t border-gray-800' : 'bg-white border-t border-gray-200'} px-6 py-3 flex items-center justify-around`}>
        <button onClick={() => setActiveTab('arena')} className={activeTab === 'arena' ? 'text-blue-500' : ''}>
          <div className="flex flex-col items-center">
            <div className={`w-10 h-10 ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-lg flex items-center justify-center mb-1`}>
              🎯
            </div>
            <span className="text-xs">Arena</span>
          </div>
        </button>
        <button onClick={() => setActiveTab('markets')} className={activeTab === 'markets' ? 'text-blue-500' : ''}>
          <div className="flex flex-col items-center">
            <TrendingUp size={20} className="mb-1" />
            <span className="text-xs">Markets</span>
          </div>
        </button>
        <button onClick={() => setActiveTab('discourse')} className={activeTab === 'discourse' ? 'text-blue-500' : ''}>
          <div className="flex flex-col items-center">
            <MessageSquare size={20} className="mb-1" />
            <span className="text-xs">Discourse</span>
          </div>
        </button>
        <button onClick={() => setActiveTab('search')} className={activeTab === 'search' ? 'text-blue-500' : ''}>
          <div className="flex flex-col items-center">
            <Search size={20} className="mb-1" />
            <span className="text-xs">Search</span>
          </div>
        </button>
      </div>
    </div>
  );

  const WalletScreen = () => (
    <div className={`min-h-screen ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
      <div className="p-6">
        <button onClick={() => setCurrentScreen('home')} className="mb-6">
          <ChevronLeft size={24} />
        </button>

        <h1 className="text-2xl font-bold mb-6">My Wallet</h1>

        <div className="bg-gradient-to-br from-blue-400 to-blue-600 rounded-3xl p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                {mockUser.avatar}
              </div>
              <span className="font-semibold">{mockUser.name}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <span>{mockUser.walletAddress}</span>
              <button>📋</button>
            </div>
          </div>

          <div className="text-4xl font-bold mb-4">${mockUser.walletBalance.toLocaleString()}</div>

          <div className="flex items-center justify-between">
            <span>{mockUser.rank}</span>
            <span>{mockUser.date}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <button className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-2xl py-4 flex items-center justify-center space-x-2`}>
            <ArrowUpRight size={20} />
            <span>Withdraw</span>
          </button>
          <button className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-2xl py-4 flex items-center justify-center space-x-2`}>
            <ArrowDownRight size={20} />
            <span>Deposit</span>
          </button>
        </div>

        <h2 className="text-xl font-bold mb-4">Recent Activity</h2>

        <div className="space-y-3">
          <div className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-xl p-4 flex items-center justify-between`}>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500"></div>
              </div>
              <div>
                <p className="font-semibold">Will Davido dr...</p>
                <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>11 YES</p>
              </div>
            </div>
            <span className="text-red-500 font-bold">-$301</span>
          </div>

          <div className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-xl p-4 flex items-center justify-between`}>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-purple-600 flex items-center justify-center">
                ⚽
              </div>
              <div>
                <p className="font-semibold">Arsenal vs M...</p>
                <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>91 MANCITY</p>
              </div>
            </div>
            <span className="text-red-500 font-bold">-$416</span>
          </div>

          <div className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-xl p-4 flex items-center justify-between`}>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center">
                <ArrowDownRight />
              </div>
              <div>
                <p className="font-semibold">Deposited $4...</p>
                <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>17/10/25</p>
              </div>
            </div>
            <span className="text-green-500 font-bold">+$41</span>
          </div>
        </div>
      </div>
    </div>
  );

  const LeaderboardScreen = () => (
    <div className={`min-h-screen ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
      <div className="p-6">
        <button onClick={() => setCurrentScreen('home')} className="mb-6">
          <ChevronLeft size={24} />
        </button>

        <h1 className="text-2xl font-bold mb-2">Top Predictors this Week 🔥</h1>

        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Users size={20} className={darkMode ? 'text-gray-500' : 'text-gray-600'} />
            <span className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>SOCIAL</span>
          </div>
          <h2 className="text-xl font-bold mb-4">Winners 👑</h2>

          <div className="space-y-3">
            {mockLeaderboard.map((user) => (
              <div key={user.rank} className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-xl p-4 flex items-center justify-between`}>
                <div className="flex items-center space-x-4">
                  <span className="text-2xl font-bold w-8">{user.rank}</span>
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-2xl">
                    {user.avatar}
                  </div>
                  <div>
                    <p className="font-bold">{user.name}</p>
                    <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>{user.handle}</p>
                  </div>
                </div>
                <span className="text-blue-500 font-bold">{user.wins} wins</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const MarketDetailScreen = ({ market }) => (
    <div className={`min-h-screen ${darkMode ? 'bg-black text-white' : 'bg-white text-black'}`}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => setSelectedMarket(null)}>
            <ChevronLeft size={24} />
          </button>
          <button>
            <MoreVertical size={24} />
          </button>
        </div>

        <div className="flex items-center space-x-3 mb-4">
          <div className={`w-16 h-16 ${darkMode ? 'bg-gray-800' : 'bg-gray-200'} rounded-full flex items-center justify-center`}>
            🇳🇬
          </div>
          <h1 className="text-2xl font-bold">{market.question}</h1>
        </div>

        <div className="mb-6">
          <div className="text-3xl font-bold mb-2">₦{market.totalVolume.replace('₦', '')}</div>
          <div className="text-green-500 flex items-center space-x-1">
            <ArrowUpRight size={20} />
            <span>+ 81.7</span>
          </div>
        </div>

        {/* Chart Timeframes */}
        <div className="flex space-x-4 mb-4 text-sm">
          <button className={darkMode ? 'text-white' : 'text-black'}>NOW</button>
          <button className={darkMode ? 'text-gray-500' : 'text-gray-400'}>6H</button>
          <button className={darkMode ? 'text-gray-500' : 'text-gray-400'}>1D</button>
          <button className={darkMode ? 'text-gray-500' : 'text-gray-400'}>1W</button>
          <button className={darkMode ? 'text-gray-500' : 'text-gray-400'}>1M</button>
          <button className={darkMode ? 'text-gray-500' : 'text-gray-400'}>ALL</button>
        </div>

        {/* Chart */}
        <div className="mb-6 h-64 relative">
          <svg className="w-full h-full" viewBox="0 0 400 200">
            {/* Colored lines representing different options */}
            <path d="M0,150 Q50,140 100,120 T200,100 T300,80 T400,60" 
                  stroke="#22c55e" fill="none" strokeWidth="2" />
            <path d="M0,120 Q50,125 100,115 T200,120 T300,130 T400,140" 
                  stroke="#3b82f6" fill="none" strokeWidth="2" />
            <path d="M0,100 Q50,95 100,100 T200,95 T300,100 T400,110" 
                  stroke="#eab308" fill="none" strokeWidth="2" />
            <path d="M0,80 Q50,85 100,90 T200,100 T300,120 T400,150" 
                  stroke="#ef4444" fill="none" strokeWidth="2" />
            
            {/* Dots at the end */}
            <circle cx="400" cy="60" r="4" fill="#22c55e" />
            <circle cx="400" cy="140" r="4" fill="#3b82f6" />
            <circle cx="400" cy="110" r="4" fill="#eab308" />
            <circle cx="400" cy="150" r="4" fill="#ef4444" />
          </svg>
          <div className={`absolute bottom-0 left-0 right-0 flex justify-around text-xs ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>
            <span>Jul</span>
            <span>Aug</span>
            <span>Sept</span>
          </div>
        </div>

        {/* Legend */}
        <div className="space-y-2 mb-6">
          {market.options.map((option, idx) => (
            <div key={idx} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${idx === 0 ? 'bg-green-500' : idx === 1 ? 'bg-blue-500' : idx === 2 ? 'bg-yellow-500' : 'bg-red-500'}`}></div>
                <span className="text-sm">{option.label}</span>
              </div>
              <span className="font-bold">{option.percentage}%</span>
            </div>
          ))}
        </div>

        {/* Trading Options */}
        <div className="space-y-3">
          {market.options.map((option, idx) => (
            <div key={idx} className={`${darkMode ? 'bg-gray-900' : 'bg-gray-100'} rounded-xl p-4 flex items-center justify-between`}>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-lg overflow-hidden">
                  <div className={`w-full h-full ${idx === 0 ? 'bg-gradient-to-br from-red-400 to-pink-500' : 'bg-gray-600'}`}></div>
                </div>
                <div>
                  <p className="font-bold">{option.label}</p>
                  {idx === 0 && <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>APC</p>}
                  {idx !== 0 && <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-600'}`}>TBA</p>}
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <p className="font-bold">{option.percentage}%</p>
                  {option.trend && (
                    <div className={`text-sm ${option.trend === 'up' ? 'text-green-500' : 'text-red-500'} flex items-center`}>
                      {option.trend === 'up' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                    </div>
                  )}
                </div>
                <button className="bg-blue-500 text-white px-6 py-2 rounded-full font-semibold">
                  Buy {option.price}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Resolution */}
        <div className="mt-6">
          <h3 className="text-xl font-bold mb-3 flex items-center">
            Resolution <ChevronRight size={20} />
          </h3>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} leading-relaxed`}>
            This market will resolve when one of the listed candidates is officially certified winner of the 2027 Nigerian Presidential Election by the Independent National Electoral Commission (INEC).
          </p>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} leading-relaxed mt-3`}>
            Verification will rely solely on INEC's final declared results or other publicly verifiable official records. If no candidate is certified or the result is...
          </p>
        </div>
      </div>
    </div>
  );

  const PostMenuModal = ({ post, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-50" onClick={onClose}>
      <div 
        className={`${darkMode ? 'bg-gray-900' : 'bg-white'} rounded-t-3xl w-full p-6 space-y-4`}
        onClick={(e) => e.stopPropagation()}
      >
        <button className="w-full text-left py-4 flex items-center space-x-3">
          <MessageSquare size={20} />
          <span>Join Discussion</span>
        </button>
        <button className="w-full text-left py-4 flex items-center space-x-3">
          <Bookmark size={20} />
          <span>Save Post</span>
        </button>
        <button className="w-full text-left py-4 flex items-center space-x-3">
          <Share2 size={20} />
          <span>Share</span>
        </button>
        <button className="w-full text-left py-4 flex items-center space-x-3">
          <VolumeX size={20} />
          <span>Mute Author</span>
        </button>
        <button className="w-full text-left py-4 flex items-center space-x-3">
          <Eye size={20} />
          <span>Hide Post / Not Interested</span>
        </button>
        <button className="w-full text-left py-4 flex items-center space-x-3 text-red-500">
          <Flag size={20} />
          <span>Report Author</span>
        </button>
        <button className="w-full text-left py-4 flex items-center space-x-3 text-red-500">
          <Ban size={20} />
          <span>Block Author</span>
        </button>
      </div>
    </div>
  );

  const MarketMenuModal = ({ onClose, onSeed, onSell, onBuy }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-50" onClick={onClose}>
      <div 
        className={`${darkMode ? 'bg-gray-900' : 'bg-white'} rounded-t-3xl w-full p-6 space-y-4`}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onSeed} className="w-full bg-blue-500 text-white py-4 rounded-full font-semibold">
          Seed market
        </button>
        <button onClick={onSell} className="w-full bg-blue-500 text-white py-4 rounded-full font-semibold">
          Sell
        </button>
        <button onClick={onBuy} className="w-full bg-blue-500 text-white py-4 rounded-full font-semibold">
          Buy
        </button>
        <button onClick={onClose} className={`w-full ${darkMode ? 'border-2 border-blue-500' : 'border-2 border-blue-500'} py-4 rounded-full font-semibold`}>
          Cancel
        </button>
      </div>
    </div>
  );

  const SideMenu = ({ onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex z-50" onClick={onClose}>
      <div 
        className={`${darkMode ? 'bg-black' : 'bg-white'} w-80 h-full p-6 overflow-y-auto`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Menu</h2>
          <button onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-2xl">
              {mockUser.avatar}
            </div>
            <div>
              <p className="font-bold text-lg">{mockUser.name}</p>
              <p className={`text-sm ${darkMode ? 'text-white' : 'text-white'}`}>@{mockUser.name.toLowerCase()}</p>
            </div>
        </div>

          <button onClick={() => {
            setCurrentScreen('wallet');
            onClose();
          }} className="w-full text-left py-3 flex items-center space-x-3">
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><Wallet size={20} /></p>
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><span>My Wallet</span></p>
          </button>

          <button onClick={() => {
            setCurrentScreen('leaderboard');
            onClose();
          }} className="w-full text-left py-3 flex items-center space-x-3">
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><Users size={20} /></p>
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><span>Leaderboard</span></p>
          </button>

          <button className="w-full text-left py-3 flex items-center space-x-3">
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><Home size={20} /></p>
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><span>My Nests</span></p>
          </button>

          <button className="w-full text-left py-3 flex items-center space-x-3">
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><Bookmark size={20} /></p>
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><span>Saved Posts</span></p>
          </button>

          <button className="w-full text-left py-3 flex items-center space-x-3">
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><TrendingUp size={20} /></p>
            <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><span>My Markets</span></p>
          </button>

          <button 
            onClick={() => {
              setDarkMode(!darkMode);
            }}
            className="w-full text-left py-3 flex items-center justify-between"
          >
            <div className="flex items-center space-x-3">
              {/* ${darkMode ? <Moon size={20} /> : <Sun size={20} />} */}
              <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><Moon size={20} /></p>
              <p className={`text-lg ${darkMode ? 'text-white' : 'text-gray-600'}`}><span>Theme</span></p>
            </div>
            <div className={`w-12 h-6 ${darkMode ? 'bg-blue-500' : 'bg-gray-300'} rounded-full relative transition-colors`}>
              <div className={`absolute top-1 ${darkMode ? 'right-1' : 'left-1'} w-4 h-4 bg-white rounded-full transition-all`}></div>
            </div>
          </button>

          <div className={`border-t ${darkMode ? 'border-gray-800' : 'border-gray-200'} pt-6 mt-6`}>
            <button className="w-full text-left py-3 text-red-500">
              Log Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // Main render logic
  if (!isAuthenticated && currentScreen !== 'home') {
    if (authStep !== 'welcome') {
      return <SignupFlow />;
    }
    return <WelcomeScreen />;
  }

  if (selectedMarket) {
    return <MarketDetailScreen market={selectedMarket} />;
  }

  if (currentScreen === 'wallet') {
    return <WalletScreen />;
  }

  if (currentScreen === 'leaderboard') {
    return <LeaderboardScreen />;
  }

  return (
    <>
      <HomeScreen />
      {showMenu && <SideMenu onClose={() => setShowMenu(false)} />}
      {selectedPost && <PostMenuModal post={selectedPost} onClose={() => setSelectedPost(null)} />}
    </>
  );
};

export default PigeonApp;